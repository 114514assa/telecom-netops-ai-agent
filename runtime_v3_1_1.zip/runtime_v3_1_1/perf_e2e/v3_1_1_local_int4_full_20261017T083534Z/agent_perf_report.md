# Telecom NetOps AI Agent 端到端性能测试

- Label: `v3_1_1_local_int4_full`
- Mode: `full`
- Base URL: `http://127.0.0.1:8001`
- Concurrency: `1,2,5`
- Requests/level: `20`
- Repeats: `3`
- Warmup: `2`

## 服务配置

```json
{
  "llm_enabled": true,
  "llm_backend": "local_hf",
  "remote_model": null,
  "local_model_id": "Qwen/Qwen2.5-0.5B-Instruct",
  "quantization": "int4",
  "device_map": "auto",
  "max_new_tokens": 96,
  "diagnosis_mode": "deterministic-parsers-and-rules",
  "llm_usage": "langchain-prompted-report-language-organization-only",
  "rag_enabled": true,
  "rag_backend": "langchain-ollama-faiss",
  "rag_top_k": 3,
  "rag_embedding_model": "qwen3-embedding:0.6b",
  "rag_knowledge_dir": "knowledge\\sanitized"
}
```

## 聚合结果

|并发|成功率均值|吞吐均值(req/s)|E2E P50均值(ms)|E2E P95均值(ms)|E2E P99均值(ms)|进程RSS峰值均值(MB)|GPU显存峰值均值(MB)|
|---:|---:|---:|---:|---:|---:|---:|---:|
|1|100.0%|0.48|1880.753|3103.815|3155.933|-|3525.0|
|2|100.0%|0.519|3465.986|6007.942|6096.741|-|3522.667|
|5|100.0%|0.505|8464.599|16079.105|16659.264|-|3566.0|

## 解释边界

- `start_latency`：POST `/api/v1/incidents` 从请求开始，到报告生成并进入 `awaiting_approval`（或审批关闭时直接 completed）的时间。
- `e2e_latency`：`mode=full` 时包含 start + HITL resume + finalize；`mode=start` 时等于 start 阶段。
- HTTP 2xx 不直接算成功；脚本同时校验业务状态。full 模式必须最终为 `completed`。
- `llm_*` 来源于报告 `generation_meta`，只有 LLM 真正运行时才有值。
- `gpu_mem_peak_mb` 来自 `nvidia-smi` 的整卡采样，可能同时包含 Ollama 和本地 HF 模型，不应直接称为“模型独占显存”。
- 性能测试时使用单 worker、关闭 `--reload`。不要用多个 worker 复制本地 HF 模型后再把结果当作单实例基线。
